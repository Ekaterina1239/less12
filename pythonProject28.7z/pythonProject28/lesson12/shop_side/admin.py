from django.contrib import admin
from shop_side.models import Category, Product

admin.site.register(Category)
admin.site.register(Product)

